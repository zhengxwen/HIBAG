### README for the files of the IMMPUTE Project ###

This file addresses relevant information based on remarks and questions.

SNP convention
--> SNP information in both HGDP and KG data sets are based (and aligned) on the human genome reference hg19.
--> Marker names across the arrays are not always consistent, so it is advised to rely on SNP position rather than SNP 'rs' names.

SNP genotyping precisions/confirmations
--> No genotype given in the datasets is inferred (imputed), all are results from actual typing.
--> Consistency between KG and HGDP has been checked. In particular, all genotypes are coded in the forward strand.

Indels & map files
--> A few SNPs included in the datasets show some insertions and deletions (indels). They appear as a string of nucleotides instead of a single one. They don't change anything in the analysis and can be regarded as a classical SNP. Frequency checking is advised for compatibility with previous datasets.
